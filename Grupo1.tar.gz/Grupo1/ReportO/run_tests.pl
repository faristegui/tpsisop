#!/usr/bin/perl
use lib 'tests';
# Here add all the tests you want to run
require 'reporto_tests.pl';